# ETOE Services Platform

The existing project is a Vite + React customer website. It is being extended in place; it is not yet a complete cross-platform booking platform.

## Current architecture and features

- `src/main.jsx` mounts the React application and shared stylesheet.
- `src/App.jsx` contains the customer homepage, category pages, booking/tracking UI, and demo operations dashboard.
- `src/data.js` defines the six service categories, 36 catalogue entries, initial offers, demo bookings, and booking statuses.
- `src/lib/supabase.js` reads active categories, services, and valid offers from Supabase when its public project settings are configured.
- `public/images/etoe-logo.png` is the supplied company logo and is used without modification.
- Customer pages use browser-history routes: `/home`, `/explore`, `/services/:category`, `/service/:serviceId`, `/cart`, `/checkout/:serviceId` or `/checkout`, `/my-bookings`, `/booking/:bookingId`, `/booking/:bookingId/track`, `/rewards`, `/referrals`, `/profile`, and `/support`. Browser back/forward navigation is supported.
- The customer app homepage has a coral ETOE header, saved-address selector, service search suggestions, offer carousel, image-led service categories, popular-service cards, and an offer/featured-service spotlight. Offer banners are sourced from active catalogue offers.
- The customer app bottom bar provides Home, Rewards, My Bookings, and Account; website mobile navigation retains its Categories shortcut. Service details, cart, checkout, booking details, and tracking are separate routes.
- The customer PWA uses the same catalogue, route pages, bookings, tracking, and notification state as the website, inside a mobile-first app shell. Its bottom navigation remains available on all screen sizes.
- The ETOE Assistant launcher is available across customer website and PWA routes. It provides service, active-offer, authenticated booking, rewards/referral cards, navigation shortcuts, and a support-ticket handoff; logged-in transcripts are stored in the shared backend.
- `supabase/functions/etoe-chat` handles AI requests and admin operations. Customer identity and ownership are checked server-side, chat requests are rate limited, and the AI receives only relevant catalogue and the authenticated customer’s own booking/reward data. It cannot execute booking mutations; customers continue through the existing booking flow and explicitly confirm there.
- The `Chatbot` admin tab manages activation, welcome text, quick replies, FAQs, provider, URL, model, customer conversations, and support replies. API keys entered there are encrypted with a server-only key and are never readable from the browser or returned to the dashboard. OpenAI-compatible endpoints and Anthropic are supported; provider hostnames are restricted by `AI_ALLOWED_API_HOSTS`.
- Authenticated owners/admins can control category visibility, mark services as popular, and create/update offers and their banner images through the admin dashboard. This requires the configured Supabase project and its existing category/service/offer policies and `offer-images` storage bucket.
- Authenticated customers can manage saved addresses against the existing Supabase `addresses` table. Without Supabase settings, demo addresses and favorite service selections stay in this browser and are not shared across devices.
- Without Supabase settings, demo bookings, offers, category visibility, service feature flags, service price edits, and status updates use browser `localStorage`; they are not shared across browsers or devices.
- Service detail pages, service search/sorting, and a multi-service cart use the existing service catalogue. The cart persists in the browser in demo mode and in `customer_cart_items` for authenticated customers when the marketplace migration is deployed.
- The marketplace migration adds server-priced multi-service booking creation, booking line items, offer/coupon validation, reward points, membership levels, referral tracking, and customer support tickets. Loyalty rules are disabled by default and must be explicitly configured by an owner/admin before points are issued.
- `supabase/migrations/20261119000000_platform_schema.sql` is the initial shared PostgreSQL schema, catalogue seed, storage setup, realtime publication setup, and role-based row-level security policies.

The website's public catalogue can read from Supabase, but the schema has not been applied to a project in this workspace. The customer and team app shells are present, but live operations still require the configured backend and provider integrations described below. Do not use this project to accept or process live customer bookings until those integrations are deployed and tested.

## Run locally

1. Install Node.js (LTS).
2. Open this project folder in VS Code.
3. Open Terminal and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL shown by Vite.

## Supabase database foundation

The database migrations target Supabase PostgreSQL. To apply them:

1. Create a Supabase project and install/use the Supabase CLI.
2. Authenticate and link this workspace with `npx supabase login` and `npx supabase link --project-ref <project-ref>`.
3. Apply the migrations with `npx supabase db push`.
4. Copy `.env.example` to `.env.local` and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` from the Supabase project settings.

The migrations enable row-level security, seed the six categories and catalogue, configure offer/job-photo storage, and add marketplace tables and role-scoped RPCs. The customer checkout uses a server-side RPC that reads current service prices and validates coupon/reward deductions before creating a booking; it does not trust browser-supplied prices. Never put a Supabase service-role key in a `VITE_` variable or browser code.

Once the environment values are set, restart Vite; the public catalogue and authenticated customer bookings load from Supabase. To bootstrap the first owner after creating an auth user, run an appropriately scoped `UPDATE public.profiles SET role = 'owner' WHERE id = '<auth-user-uuid>';` from the trusted Supabase SQL editor. Never expose the service-role key.

Live OTP, online payments, wallet balances, and push/SMS notification delivery are not configured. The wallet control explains that it is unavailable and links to Rewards; it does not display a fabricated balance. Time slots are shown during booking, and service durations, packages, add-ons, included/excluded work, and review moderation are not yet managed through the customer catalogue UI. There are no AI/provider credentials in this repository.

## AI customer chatbot

The chatbot uses the existing Supabase project, not a separate application server. Apply the chatbot migration with the other database migrations, then deploy the Edge Function:

```bash
npx supabase db push
npx supabase functions deploy etoe-chat
```

Set the provider values as Supabase Function secrets. These values are server-only; never use a `VITE_` prefix or put a real key in source control:

```bash
npx supabase secrets set AI_API_KEY="your-provider-key" AI_API_URL="https://api.openai.com/v1/chat/completions" AI_MODEL="your-model-name" AI_PROVIDER="openai-compatible" AI_CONFIG_ENCRYPTION_KEY="your-random-secret-at-least-32-characters" AI_ALLOWED_API_HOSTS="openai.com,openrouter.ai,groq.com,together.xyz,anthropic.com"
```

Alternatively, an authenticated owner/admin can save a key in the Chatbot admin tab. That key is encrypted at rest using `AI_CONFIG_ENCRYPTION_KEY`; only a masked configured/not-configured state is returned to the UI. Leave the key field blank to retain the saved value. The dashboard connection test uses current unsaved values and does not save the key. If configuring another provider URL, add its hostname to `AI_ALLOWED_API_HOSTS` as a server secret. `AI_API_URL`, `AI_MODEL`, and `AI_PROVIDER` can provide server defaults; the admin settings can override those defaults.

The function accepts OpenAI-compatible chat-completion endpoints and Anthropic Messages endpoints. It validates Supabase customer identity for private data, filters bookings/rewards/referrals to the signed-in customer, limits chat requests, and does not offer model tools for booking or account changes. Service recommendations and offers come from the live catalogue. The assistant directs booking requests into the existing date/time/address and confirmation flow; it does not claim to create or alter bookings itself. Guest conversations are not associated with a customer profile.

Without a configured Supabase project, applied migration, deployed function, and provider credentials, the widget displays navigation/support fallbacks rather than pretending the AI is connected. This workspace has no configured ETOE Supabase project or provider key, so live provider calls, database RLS, and admin writes must be validated in the target staging project before launch.

## Installable customer and team apps

The existing React application also serves two installable PWA app surfaces:

- Customer app: install from `/home#app/customer` or open that URL directly
- Team/internal app: open `/#app/team`

Both surfaces can be installed by supported browsers through the browser "Install app" action. Their app shell is cached for offline fallback, and the app icons use the existing ETOE logo asset.

Without Supabase project settings, app sign-in uses explicit demo mode and does not authenticate real users. With `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`, customer sign-in, email/password signup, email confirmation, and password recovery use Supabase Auth; email confirmation and redirect URLs must be configured in that project. The team route loads the authenticated profile role from `public.profiles`; customer mode maps the session to the customer role. Phone/OTP verification remains deferred.

The customer PWA keeps website and app navigation on the same React state and URLs, with dedicated screens for service exploration and details, cart, checkout, bookings, booking details, tracking, rewards, referrals, profile, and support. It also exposes in-app notification history, saved addresses, and device-local favorite services. Saved addresses, customer bookings, carts, rewards, referrals, and support tickets sync through Supabase only when a configured, authenticated customer session and the migrations are available. Demo login, demo bookings, and favorites are local to the current browser.

Notification history can be read from the existing Supabase notification table when configured. Browser notifications require permission; background push delivery still needs a push provider and server-side subscription delivery. Online payments, OTP, package/add-on pricing, account deletion, and cross-device favorites are not wired up and are not simulated as successful. The team PWA currently presents role-aware navigation and dashboards for owner, admin, manager, tracking team, field officer and service staff. Booking/status/job actions still require the secured API and assignment workflow described in the database migrations.

## Booking tracking

The customer website and customer PWA share booking data through the dedicated My Bookings, Booking Details, and Track Booking routes. The premium tracking page shows the Booking ID, service, schedule, address, team, payment, ETA and a vertical status timeline. Demo status updates from the team PWA are synchronized with other open website/customer-app tabs through browser local storage. No map or GPS location is displayed.

Live status synchronization across separate devices requires applying the Supabase migrations and using the team/customer APIs and realtime subscriptions. Status history and review creation use the existing policies; secure cancellation and rescheduling still require dedicated backend operations.

## Real-time order workflow

The order lifecycle migration is in `supabase/migrations/20261119010000_booking_order_workflow.sql`. It adds:

- Pending, confirmed and rejected admin order states
- Team assignment, acceptance, rejection and 10-minute acceptance deadlines
- Reassignment and acceptance audit history
- User-specific in-app notifications with deduplication and delivery/retry fields
- Notification settings and realtime publication for bookings, status history, audit logs and notifications
- SECURITY DEFINER RPC functions for booking creation, admin confirmation/rejection, team assignment, team acceptance/rejection, status updates and timeout handling

The marketplace migration is `supabase/migrations/20261120000000_customer_marketplace.sql`. It adds persistent customer carts and booking items; server-calculated multi-service checkout with offer/coupon and points validation; reward ledgers with idempotent completion/referral credits and configurable expiry; referral codes; rewards admin settings/manual audited adjustments; and customer support tickets. Before live use, apply all migrations, configure `.env.local`, create role profiles and teams, and validate the schema and RPCs in the ETOE Supabase project. The browser UI is a client surface, not a substitute for server-side auth and RLS. Without project settings, the app remains in explicit demo mode and browser-local workflow data is not suitable for production.

## Production work still required

Before launch, apply and validate all migrations and the `etoe-chat` function in the ETOE Supabase project; validate authenticated chatbot history, row-level authorization, encrypted key rotation, provider errors, and admin support handoff in staging; validate role-based category, offer, and featured-service administration; persist service price edits; connect payment and notification providers; build both native mobile apps; and add deployment configuration and end-to-end tests.
